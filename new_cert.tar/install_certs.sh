#!/bin/sh

CA_DIR=/etc/sf/keys/fireamp/thawte_roots
CA_FILE=iosCerts.tgz
CA_CERT_CHAIN=iosCerts.pem

echo "installing CA certificates to ${CA_DIR} ..."
if [[ -d ${CA_DIR} && -f ${CA_FILE} && -f ${CA_CERT_CHAIN} ]]; then
  cp -f ${CA_FILE} ${CA_DIR}
  pushd ${CA_DIR}
  tar -xzvf ./${CA_FILE}
  chown root:root *.pem
  c_rehash .
  rm ${CA_FILE}
  popd
  cp ${CA_CERT_CHAIN} ${CA_DIR}
else
  echo "${CA_DIR} or ${CA_DIR}/${CA_FILE} or ${CA_CERT_CHAIN} not found!"
  exit 1
fi

echo "Exiting $0."
